<section class="slider11 p%PATTERN%">
  <div class="slider">
