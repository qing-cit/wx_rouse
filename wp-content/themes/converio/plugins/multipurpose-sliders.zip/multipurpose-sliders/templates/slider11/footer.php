  </div>
</section>

<section class="landing-form">
  <form action="%PATH%landing-page-form.php" method="post">
    <h2>%FORM_TITLE%</h2>
    <input type="hidden" name="iworks_slider_email" value="%EMAIL%" />
    <p><label for="name">%Name%</label><input name="name" id="name"></p>
    <p><label for="email">%Email%</label><input name="email" id="email"></p>
    <p><label for="service">%Service%</label><select name="service" id="service">%SERVICE_OPTIONS%</select></p>
    <p><label class="chk checkbox" for="chk"><input type="checkbox" name="chk" id="chk" value="1"> check the checkbox</label></p>
    <p><button name="submit" type="submit">%FOOTER_BUTTON%</button></p>
  </form>
</section>
