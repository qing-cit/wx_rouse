    <article>
      <div class="video">%VIDEO%</div>
      <div>%CONTENT%</div>
    </article>

