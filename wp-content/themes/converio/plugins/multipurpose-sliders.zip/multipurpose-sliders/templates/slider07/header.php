<section class="slider7"><div class="p%PATTERN%"><div>
  <div class="slider">

