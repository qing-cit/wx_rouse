<section class="slider12 p%PATTERN%">
  <div class="slider">
