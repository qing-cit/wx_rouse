  <article>
    <div class="img">%IMG%</div>
    <div class="text">
      <h3>%TITLE%</h3>
%CONTENT%
%LINK_TEMPLATE%
    </div>
  </article>

