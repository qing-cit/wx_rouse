<section class="slider6 p%PATTERN%">
  <div><div>
    <section class="menu">
      <a href="#" class="prev">%PREVIOUS%</a>
      <div>
         <ul>
          %THUMBNAILS_LIST%
        </ul>
      </div>
      <a href="#" class="next">%NEXT%</a>
    </section>
    <section class="slides">

