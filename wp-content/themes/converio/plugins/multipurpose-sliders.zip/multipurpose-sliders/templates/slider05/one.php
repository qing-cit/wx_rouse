      <article>
        <div class="img-border">%IMG%</div>
        <h3>%TITLE%</h3>
      </article>
