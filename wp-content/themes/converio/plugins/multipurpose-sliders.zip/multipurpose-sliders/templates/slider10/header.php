<section class="slider10">
  <a href="#" class="prev">%PREVIOUS%</a>
  <a href="#" class="next">%NEXT%</a>
  <ul>
