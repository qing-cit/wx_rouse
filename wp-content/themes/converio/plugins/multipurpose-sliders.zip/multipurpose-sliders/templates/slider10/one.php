    <li><a href="%LINK_URL%"><span class="img-border">%IMG%</span></a></li>

