<section class="slider slider8">
