  </div>
  <ul class="slider-titles">%THUMBNAILS_LIST%</ul>
</section>
