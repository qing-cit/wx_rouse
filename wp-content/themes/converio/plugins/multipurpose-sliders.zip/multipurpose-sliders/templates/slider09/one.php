  <article>
    <div><div><span class="img-border">%IMG%</span></div></div>
%CONTENT%
    <p>%LINK_TEMPLATE% %LINK_MORE_TEMPLATE%</p>
  </article>

