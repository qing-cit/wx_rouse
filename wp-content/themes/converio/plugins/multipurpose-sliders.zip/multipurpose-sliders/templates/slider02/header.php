<section class="slider slider2">

