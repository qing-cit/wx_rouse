  <article>
    %IMG%
    <div>
      <h3>%TITLE%</h3>
    </div>
  </article>

