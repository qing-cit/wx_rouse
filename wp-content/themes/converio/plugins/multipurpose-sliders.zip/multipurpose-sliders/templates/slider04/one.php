  <article>
    <div><span><span class="img-border">%IMG%</span></span></div>
    <h3>%TITLE%</h3>
%CONTENT%
%LINK_TEMPLATE%
  </article>

