<section class="slider4 p%PATTERN%">
  <div class="slider">
