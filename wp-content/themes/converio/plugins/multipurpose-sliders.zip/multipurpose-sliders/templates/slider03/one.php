  <article>
    <span class="img-border">%IMG%</span>
    <h3>%TITLE%</h3>
%CONTENT%
%LINK_TEMPLATE%
  </article>

