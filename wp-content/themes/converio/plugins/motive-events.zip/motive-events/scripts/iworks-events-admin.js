jQuery( document ).ready( function( $ ) {
    console.log(1);
    $( ".datepicker" ).datepicker();
});

