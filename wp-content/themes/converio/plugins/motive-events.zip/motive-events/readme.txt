=== Motive Events ===
Contributors: iworks
Requires at least: 3.8
Tested up to: 4.0
Stable tag: 1.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Allow to manage events

== Description ==

== Installation ==

1. Upload Motive Events to your plugins directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Configure Motive Events plugin using Events -> Settings

== Changelog ==

= 1.4 (2014-10-31)

* IMPROVEMENT: added pagination on event taxonomy page
* BUGFIX: fixed a problem with events having hour

= 1.3.5

* BUGFIX: I fixed a problem with links.
* IMPROVEMENT: added widget calendar with upcoming eveents

= 1.3.4

* IMPROVEMENT: when links are hash, then display only existing categories.
* IMPROVEMENT: added filter "iworks_events_thumbnails" - use this filter to change post thumbnail images.

